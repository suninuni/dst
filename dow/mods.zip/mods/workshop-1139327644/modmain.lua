local require = GLOBAL.require

Assets = {

    Asset( "ANIM", "anim/abigail_meter.zip"),
    Asset( "ANIM", "anim/beefalo_meter.zip"),
    Asset( "ANIM", "anim/bishop_meter.zip"),
    Asset( "ANIM", "anim/bunny_meter.zip"),
    Asset( "ANIM", "anim/catcoon_meter.zip"),
    Asset( "ANIM", "anim/chester_meter.zip"),
    Asset( "ANIM", "anim/cspider_meter.zip"),
    Asset( "ANIM", "anim/dangler_meter.zip"),
    Asset( "ANIM", "anim/darkchester_meter.zip"),
    Asset( "ANIM", "anim/emerling_meter.zip"),
    Asset( "ANIM", "anim/glommer_meter.zip"),
    Asset( "ANIM", "anim/knight_meter.zip"),
    Asset( "ANIM", "anim/mandrake_meter.zip"),
    Asset( "ANIM", "anim/merm_meter.zip"),
    Asset( "ANIM", "anim/pig_meter.zip"),
    Asset( "ANIM", "anim/rocky_meter.zip"),
    Asset( "ANIM", "anim/rook_meter.zip"),
    Asset( "ANIM", "anim/shadow_meter.zip"),
    Asset( "ANIM", "anim/shavebeef_meter.zip"),
    Asset( "ANIM", "anim/snowchester_meter.zip"),
    Asset( "ANIM", "anim/spider_meter.zip"),
    Asset( "ANIM", "anim/spitter_meter.zip"),
    Asset( "ANIM", "anim/swarrior_meter.zip"),
    Asset( "ANIM", "anim/tallbird_meter.zip"),
    Asset( "ANIM", "anim/teenbeef_meter.zip"),
    Asset( "ANIM", "anim/follow_meter.zip"),
    Asset( "ANIM", "anim/loyal_bar.zip"),
    -- All animations will be added into one file once happy with them

    Asset("ATLAS", "images/status_bg.xml"),

    Asset("ATLAS", "images/command_where.xml"),
    Asset("IMAGE", "images/command_where.tex"),
    Asset("ATLAS", "images/command_pause.xml"),
    Asset("IMAGE", "images/command_pause.tex"),
    Asset("ATLAS", "images/command_play.xml"),
    Asset("IMAGE", "images/command_play.tex"),
    Asset("ATLAS", "images/command_remove.xml"),
    Asset("IMAGE", "images/command_remove.tex"),
    Asset("ATLAS", "images/command_magichat.xml"),
    Asset("IMAGE", "images/command_magichat.tex"),

    Asset("ATLAS", "images/down_arrow.xml"),
    Asset("IMAGE", "images/down_arrow.tex"),
    Asset("ATLAS", "images/up_arrow.xml"),
    Asset("IMAGE", "images/up_arrow.tex"),

}

local GetGlobal = function(gname,default)
	local res = GLOBAL.rawget(GLOBAL,gname)
	if res == nil and default ~= nil then
		GLOBAL.rawset(GLOBAL,gname,default)
		return default
	end
	return res
end

local GetTime = GLOBAL.GetTime
local TheNet = GLOBAL.TheNet
local CLIENT_SIDE =	 GLOBAL.TheNet:GetIsClient() or (TheNet:GetIsServer() and not TheNet:IsDedicated())

local BadgeAssets = function( str )

	if str == "pigman" then
		return "pig_meter"
	elseif str == "chester" then
		return "chester_meter"
	elseif str == "abigail" then
		return "abigail_meter"
	elseif str == "babybeefalo" then
		return "teenbeef_meter"
	elseif str == "bishop_nightmare" then
		return "bishop_meter"
	elseif str == "bunnyman" then
		return "bunny_meter"
	elseif str == "catcoon" then
		return "catcoon_meter"
	elseif str == "chester" then
		return "chester_meter"
	elseif str == "emerling" then
		return "emerling_meter"
	elseif str == "glommer" then
		return "glommer_meter"
	elseif str == "knight_nightmare" then
		return "knight_meter"
	elseif str == "mandrake" then
		return "mandrake_meter"
	elseif str == "merm" then
		return "merm_meter"
	elseif str == "pigman" then
		return "pig_meter"
	elseif str == "rocky" then
		return "rocky_meter"
	elseif str == "rook_nightmare" then
		return "rook_meter"
	elseif str == "shadowwaxwell" then
		return "shadow_meter"
	elseif str == "smallbird" or str == "teenbird" or str == "tallbird" then
		return "tallbird_meter"
	elseif str == "spider" then
		return "spider_meter"
	elseif str == "spider_hider" then
		return "cspider_meter"
	elseif str == "spider_spitter" then
		return "spitter_meter"
	elseif str == "spider_dropper" then
		return "dangler_meter"
	elseif str == "spider_warrior" then
		return "swarrior_meter"
	else
		return "follow_meter"
	end	
	
end

--nice round function
local round2 = function(num, idp)
	return GLOBAL.tonumber(string.format("%." .. (idp or 0) .. "f", num))
end

	function GetTestString( viewer, TheLeader, following, follower1, follower2, follower3, follower4, follower5, follower6 ) --Отныне форкуемся от Tell Me, ибо всё сложно.

		desc_table = {}
				
		local item = nil
		local prefab = nil
		local c = nil

		local FollowerTable = {}
		
		if follower1 ~= nil then
			if follower1.prefab == "chester" or follower1.prefab == "glommer" or follower1.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower1, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower1, loyalty = follower1.components.follower:GetLoyaltyPercent() } )
			end
		end
		if follower2 ~= nil then
			if follower2.prefab == "chester" or follower2.prefab == "glommer" or follower2.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower2, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower2, loyalty = follower2.components.follower:GetLoyaltyPercent() } )
			end
		end
		if follower3 ~= nil then
			if follower3.prefab == "chester" or follower3.prefab == "glommer" or follower3.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower3, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower3, loyalty = follower3.components.follower:GetLoyaltyPercent() } )
			end
		end
		if follower4 ~= nil then
			if follower4.prefab == "chester" or follower4.prefab == "glommer" or follower4.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower4, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower4, loyalty = follower4.components.follower:GetLoyaltyPercent() } )
			end
		end
		if follower5 ~= nil then
			if follower5.prefab == "chester" or follower5.prefab == "glommer" or follower5.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower5, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower5, loyalty = follower5.components.follower:GetLoyaltyPercent() } )
			end
		end
		if follower6 ~= nil then
			if follower6.prefab == "chester" or follower6.prefab == "glommer" or follower6.prefab == "abigail" then
				table.insert( FollowerTable, { ent = follower6, loyalty = 1 } )				
			else
				table.insert( FollowerTable, { ent = follower6, loyalty = follower6.components.follower:GetLoyaltyPercent() } )
			end
		end

		table.sort( FollowerTable, function( a, b ) return a.loyalty > b.loyalty end )
		
		for k, v in pairs ( FollowerTable ) do
			
			print( "Request Received:", k, v )
			
			item = v.ent
			prefab = item.prefab
			c = item.components
		
			if c.follower or ( c.domesticatable ~= nil and c.domesticatable.GetObedience ~= nil ) then

				table.insert( desc_table, "¦" .. tostring( TheLeader ) )
				table.insert( desc_table, tostring( following ) )
				
				if prefab == "beefalo" then
					if c.beard.bits == 0 then
						table.insert( desc_table, "shavebeef_meter" )
					else
						table.insert( desc_table, "beefalo_meter" )
					end
				else
					table.insert( desc_table, BadgeAssets( tostring( prefab ) ) )
				end
									
				if c.named then
					table.insert( desc_table, tostring(c.named.name) )
				elseif prefab == "abigail" or prefab == "chester" or prefab == "glommer" then
					table.insert( desc_table, tostring(item.name) )
				else
					item:AddComponent( "named" )
					c.named.possiblenames = GLOBAL.STRINGS.PIGMANNAMES
					c.named:PickNewName()
					table.insert( desc_table, tostring(c.named.name) )
				end
				
				-- Follower Loyalty
				
					-- NB: 	Need fix for Loyality already built up and not saving the leader. 
					-- 		Either fix leader or remove the loyalty on new leader.
				if prefab == "chester" or prefab == "abigail" or prefab == "glommer" or prefab == "mandrake" then
					table.insert( desc_table, tostring( GLOBAL.GetRandomMinMax( 0.9999, 1 ) ) )
					table.insert( desc_table, "Forever" )
				elseif prefab == "smallbird" or prefab == "teenbird" or prefab == "tallbird" then
					mx = c.hunger.maxfhunger
					cur = c.hunger:GetPercent()						
					table.insert( desc_table, tostring( cur ) )
					table.insert( desc_table, tostring( mx ) )
				elseif c.follower.maxfollowtime then
					mx = c.follower.maxfollowtime
					cur = c.follower:GetLoyaltyPercent()	
					if math.floor( cur * mx + 0.5 ) > 0 then
						table.insert( desc_table, tostring( cur ) )
						table.insert( desc_table, tostring( mx ) )
					elseif math.floor( cur * mx + 0.5 ) <= 0.1 and c.follower.leader and c.follower.leader and c.follower.leader:IsValid() 
						and c.follower.leader:HasTag( "player" ) and c.follower.leader.name and c.follower.leader.name ~= "" then
							c.follower.leader.components.leader:RemoveFollower( item )
							table.insert( desc_table, "0" )
							table.insert( desc_table, tostring( mx ) )
					end
				end
				
				-- Follower Health
				if c.health then
					local mx = math.ceil( c.health.maxhealth - c.health.minhealth )
					local cur = math.ceil( c.health.currenthealth - c.health.minhealth )
					if cur > mx then cur = mx end
						table.insert( desc_table, tostring( c.health:GetPercent() ) )
						table.insert( desc_table, tostring( cur ) )
				end
								
				-- Domestication
				if c.domesticatable ~= nil and c.domesticatable.GetObedience ~= nil then
					local obedience = c.domesticatable:GetObedience()
					if obedience ~= 0 then
						table.insert( desc_table, tostring( round2( obedience * 100, 0 ) ) )
					else
						table.insert( desc_table, "0" )
					end
				else
						table.insert( desc_table, "0" )			
				end
				
			end

		end
			
		return table.concat( desc_table, "|" )

	end
	
	if CLIENT_SIDE then
				
		local function spairs( t, order )
			local keys = {}
			local i = 0
			for k in pairs(t) do keys[#keys+1] = k end
			if order then table.sort(keys, function(a,b) return order(t, a, b) end) end
			return function()
				i = i + 1
				if keys[i] then return keys[i], t[keys[i]] end
			end
		end
				
		AddClassPostConstruct("widgets/statusdisplays", function(hoverer)
			
			controls = hoverer
			
			local Badge = require "widgets/badge"
			local Text = require "widgets/text"
			local ImageButton = require "widgets/imagebutton"

			local FollowerDefault = Class(Badge, function(status, owner)
				Badge._ctor(status, "follower_meter", owner)
			end)

			local Loyaltybar = Class(Badge, function(status, owner)
				Badge._ctor(status, "loyal_bar", owner)
			end)

			local HUDdown = 0 --GetModConfigData("OptionHUDdown")
			local HUDhorizontal = 0 --GetModConfigData("OptionHUDhorizontal")

			local foundchester = false
			local foundglommer = false

			for i = 1, 6, 1 do

				if GLOBAL.TheWorld.ismastersim then
			
					if i == 1 then
						controls.follower1 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower1
					elseif i == 2 then
						controls.follower2 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower2            
					elseif i == 3 then
						controls.follower3 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower3          
					elseif i == 4 then
						controls.follower4 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower4            
					elseif i == 5 then
						controls.follower5 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower5            
					elseif i == 6 then
						controls.follower6 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.follower6            
					end
					
				else
				
					if i == 1 then
						controls.clientfollower1 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower1
					elseif i == 2 then
						controls.clientfollower2 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower2            
					elseif i == 3 then
						controls.clientfollower3 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower3          
					elseif i == 4 then
						controls.clientfollower4 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower4            
					elseif i == 5 then
						controls.clientfollower5 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower5            
					elseif i == 6 then
						controls.clientfollower6 = controls:AddChild(FollowerDefault(GLOBAL.ThePlayer))
						CurrentBadge = controls.clientfollower6            
					end
				
				end

				CurrentBadge:SetPercent(1)                    
				CurrentBadge:SetHAnchor(GLOBAL.ANCHOR_LEFT)
				CurrentBadge:SetVAnchor(GLOBAL.ANCHOR_TOP)
				CurrentBadge:Hide()
				
				CurrentBadge.loyaltime = CurrentBadge:AddChild(Loyaltybar(owner))
				CurrentBadge.myname = CurrentBadge:AddChild(Text(GLOBAL.NUMBERFONT, 15))

				CurrentBadge.loyaltime:SetScale(.4,.43,1)
				CurrentBadge.loyaltime:SetPosition(-.5,-25,0)
				CurrentBadge.loyaltime.num:SetPosition(5, -35, 0)
				CurrentBadge.loyaltime:SetPercent(1)
				CurrentBadge.loyaltime:Hide()                  

				CurrentBadge.myname:SetHAlign(GLOBAL.ANCHOR_MIDDLE)
				CurrentBadge.myname:SetPosition(3.5, 40.5, 0)
				CurrentBadge.myname:SetScale(1,.78,1)
				CurrentBadge.myname:Hide()
				
			end
			
			hoverer.inst:DoPeriodicTask(2, function()
						
				local ClientCurrentFollowers = 0
				local leader = nil
				local follow1 = nil
				local follow2 = nil
				local follow3 = nil
				local follow4 = nil
				local follow5 = nil
				local follow6 = nil

				if GLOBAL.ThePlayer ~= nil then
								
					-- Server
					if GLOBAL.TheWorld.ismastersim then

						if hoverer.owner ~= nil and hoverer.owner.components.leader ~= nil then

							local Profile = require("playerprofile")()

							local increment = 60 + (Profile:GetHUDSize() * 4)

							local CurrentBadge = nil
							local BadgeCount = 1
							local badgeV = -60

							local CurrentFollowers = {}
							
							-- CHESTER & GLOMMER
							for k,item in pairs( GLOBAL.ThePlayer.components.inventory.itemslots ) do
								if ( item.prefab == "chester_eyebone" or item.prefab == "glommerflower" ) and BadgeCount < 3 then 
									local x, y, z = GLOBAL.ThePlayer.Transform:GetWorldPosition()
									local SpecialFollower = nil
									local SpecialFollowerEnt = nil
									
									if BadgeCount == 1 then 
										CurrentBadge = controls.follower1
									elseif BadgeCount == 2 then 
										CurrentBadge = controls.follower2
									end
									
									if item.prefab == "chester_eyebone" then
										SpecialFollower = GLOBAL.TheSim:FindEntities( x, y, z, 75, { "chester" } )
									elseif item.prefab == "glommerflower" then
										SpecialFollower = GLOBAL.TheSim:FindEntities( x, y, z, 75, { "glommer" } )										
									end
																		
									if SpecialFollower ~= nil then
										for k, v in pairs ( SpecialFollower ) do
											--print( "Follower: ", v )
											SpecialFollowerEnt = v
										end
									end
																		
									if SpecialFollowerEnt and SpecialFollowerEnt.components and SpecialFollowerEnt.components.health:GetPercent() then
										
										--print( "Follower Display: ", SpecialFollowerEnt )
										
										if item.prefab == "chester_eyebone" then
											foundchester = true
											if SpecialFollowerEnt:HasTag("spoiler") then
												CurrentBadge.anim:GetAnimState():SetBank("darkchester_meter")
												CurrentBadge.anim:GetAnimState():SetBuild("darkchester_meter")
											elseif SpecialFollowerEnt:HasTag("fridge") then
												CurrentBadge.anim:GetAnimState():SetBank("snowchester_meter")
												CurrentBadge.anim:GetAnimState():SetBuild("snowchester_meter")
											else
												CurrentBadge.anim:GetAnimState():SetBank("chester_meter")
												CurrentBadge.anim:GetAnimState():SetBuild("chester_meter")
											end										
										elseif item.prefab == "glommerflower" then
											CurrentBadge.anim:GetAnimState():SetBank("glommer_meter")
											CurrentBadge.anim:GetAnimState():SetBuild("glommer_meter")
											foundglommer = true
										end

										if item.prefab == "glommerflower" and item.components.perishable then
											CurrentBadge.loyaltime:SetPercent( item.components.perishable:GetPercent() )
											CurrentBadge.loyaltime.num:SetString( tostring( math.floor( item.components.perishable:GetPercent() * 100 ) ) .. "%" )                            
										else
											CurrentBadge.loyaltime:SetPercent( 1 )
											CurrentBadge.loyaltime.num:SetString( "Forever" )
										end
										
										CurrentBadge:SetPercent( SpecialFollowerEnt.components.health:GetPercent() )	
										CurrentBadge.num:SetString( tostring( math.ceil( SpecialFollowerEnt.components.health.currenthealth - SpecialFollowerEnt.components.health.minhealth ) ) )
										CurrentBadge.myname:SetString( SpecialFollowerEnt.name )
										CurrentBadge:Show()
										CurrentBadge.loyaltime:Show()
										CurrentBadge.myname:Show()

										CurrentBadge:SetScale(1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10))
										CurrentBadge:SetPosition(104 + ((BadgeCount - 1) * increment) + (Profile:GetHUDSize() * 4.8), badgeV - Profile:GetHUDSize(), 50)
																																						
										if SpecialFollowerEnt.components.health:GetPercent() < .15 then 
											CurrentBadge.pulse:GetAnimState():SetMultColour(1,.5,0,1) -- Red
											CurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")											
										elseif SpecialFollowerEnt.components.health:GetPercent() < .3 then 
											CurrentBadge.pulse:GetAnimState():SetMultColour(1,.5,0,1) -- Orange
											CurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")
										end
										
										BadgeCount = BadgeCount + 1
										badgeV = -60
										if BadgeCount % 2 == 0 then badgeV = -100 end
									end 										
									
								end
							end
						
							if hoverer.owner.components.leader:CountFollowers() < 6 then controls.follower6:Hide() end
							if hoverer.owner.components.leader:CountFollowers() < 5 then controls.follower5:Hide() end 
							if hoverer.owner.components.leader:CountFollowers() < 4 then controls.follower4:Hide() end
							if hoverer.owner.components.leader:CountFollowers() < 3 then controls.follower3:Hide() end 
							if hoverer.owner.components.leader:CountFollowers() < 2 and BadgeCount < 3 then controls.follower2:Hide() end
							if hoverer.owner.components.leader:CountFollowers() < 1 and BadgeCount < 2 then controls.follower1:Hide() end
						
							if hoverer.owner.components.leader:CountFollowers() > 0 then
																		
								for k, v in pairs( GLOBAL.ThePlayer.components.leader.followers ) do 
									CurrentFollowers[k] = k.components.follower:GetLoyaltyPercent()
								end
																
								for k, v in spairs( CurrentFollowers, function( t, a, b ) return t[a] > t[b] end ) do
								
									CurrentBadge = nil
								
									if BadgeCount == 1 then 
										CurrentBadge = controls.follower1
									elseif BadgeCount == 2 then 
										CurrentBadge = controls.follower2
									elseif BadgeCount == 3 then 
										CurrentBadge = controls.follower3
									elseif BadgeCount == 4 then 
										CurrentBadge = controls.follower4
									elseif BadgeCount == 5 then 
										CurrentBadge = controls.follower5
									elseif BadgeCount == 6 then 
										CurrentBadge = controls.follower6 
									end								
									
									if CurrentBadge ~= nil then
									
										if k.prefab == "beefalo" then
											if k.components.beard.bits == 0 then
												CurrentBadge.anim:GetAnimState():SetBank( "shavebeef_meter" )
												CurrentBadge.anim:GetAnimState():SetBuild( "shavebeef_meter" )
											else
												CurrentBadge.anim:GetAnimState():SetBank( "beefalo_meter" )
												CurrentBadge.anim:GetAnimState():SetBuild( "beefalo_meter" )
											end
										else
											CurrentBadge.anim:GetAnimState():SetBank( BadgeAssets( tostring( k.prefab ) ) )
											CurrentBadge.anim:GetAnimState():SetBuild( BadgeAssets( tostring( k.prefab ) ) )
										end
																		
										if k.components.health ~= nil then
											CurrentBadge:SetPercent( k.components.health:GetPercent() )	
											CurrentBadge.num:SetString( tostring( math.ceil( k.components.health.currenthealth - k.components.health.minhealth ) ) )
											if k.components.health:GetPercent() < .15 then 
												CurrentBadge.pulse:GetAnimState():SetMultColour(1,.5,0,1) -- Red
												CurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")											
											elseif k.components.health:GetPercent() < .3 then 
												CurrentBadge.pulse:GetAnimState():SetMultColour(1,.5,0,1) -- Orange
												CurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")
											end
										end 
										
										if k.components.follower ~= nil then
											if k.prefab == "abigail" or k.prefab == "mandrake" then
												CurrentBadge.loyaltime:SetPercent( 1 )
												CurrentBadge.loyaltime.num:SetString( "Forever" )
											elseif k.prefab == "smallbird" or k.prefab == "teenbird" or k.prefab == "tallbird" then												
												CurrentBadge.loyaltime:SetPercent( k.components.hunger:GetPercent() )
												CurrentBadge.loyaltime.num:SetString( tostring( math.floor( k.components.hunger:GetPercent() * 100 ) ) .. "%" )                            
											elseif k.components.follower:GetLoyaltyPercent() > 0 then
												CurrentBadge.loyaltime:SetPercent( k.components.follower:GetLoyaltyPercent() )
												CurrentBadge.loyaltime.num:SetString( tostring( math.floor( k.components.follower:GetLoyaltyPercent() * 100 ) ) .. "%" )                            
											else
												k.components.follower.leader.components.leader:RemoveFollower( k )
												print( "Follower Removed: ", k )
											end
										end
										
										if k.components.named then
											CurrentBadge.myname:SetString( k.components.named.name )
										elseif k.prefab == "abigail" then
											CurrentBadge.myname:SetString( k.name )
										else
											k:AddComponent( "named" )
											k.components.named.possiblenames = GLOBAL.STRINGS.PIGMANNAMES
											k.components.named:PickNewName()
										end
										
										CurrentBadge:Show()
										CurrentBadge.loyaltime:Show()
										CurrentBadge.myname:Show()

										CurrentBadge:SetScale(1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10))
										CurrentBadge:SetPosition(104 + ((BadgeCount - 1) * increment) + (Profile:GetHUDSize() * 4.8), badgeV - Profile:GetHUDSize(), 50)
										
									end
																		
									BadgeCount = BadgeCount + 1
									badgeV = -60
									if BadgeCount % 2 == 0 then badgeV = -100 end
									
								end
							
							end
							
						end
					
					-- Client
					else
											
						print( "Follower Count 1:", ClientCurrentFollowers )
											
						-- CHESTER & GLOMMER
						for k, item in pairs( GLOBAL.ThePlayer.replica.inventory:GetItems() ) do
							
							if ( item.prefab == "chester_eyebone" or item.prefab == "glommerflower" ) and ClientCurrentFollowers < 2 then 
								local x, y, z = GLOBAL.ThePlayer.Transform:GetWorldPosition()
								local SpecialFollower = nil
								local SpecialFollowerEnt = nil
								
								if item.prefab == "chester_eyebone" then
									SpecialFollower = GLOBAL.TheSim:FindEntities( x, y, z, 75, { "chester" } )
								elseif item.prefab == "glommerflower" then
									SpecialFollower = GLOBAL.TheSim:FindEntities( x, y, z, 75, { "glommer" } )										
								end
																	
								if SpecialFollower ~= nil then
									for k, v in pairs ( SpecialFollower ) do
										--print( "Follower: ", v )
										if ClientCurrentFollowers == 0 then 
											follow1 = v
										end
										if ClientCurrentFollowers == 1 and v ~= follow1 then 
											follow2 = v 
										end										
									end
									leader = GLOBAL.ThePlayer.GUID
									ClientCurrentFollowers = ClientCurrentFollowers + 1
								end
								
							end
						end	
						
						print( "Special Followers 1: ", follow1, follow2 )
						
						--function FindEntity(inst, radius, fn, musttags, canttags, mustoneoftags)		
						local x, y, z = GLOBAL.ThePlayer.Transform:GetWorldPosition()
						-- { "bird", "flower", "wall", "tree", "boulder" }
						local ents = GLOBAL.TheSim:FindEntities( x, y, z, 75 ) -- or we could include a flag to the search?
						
						for k, v in ipairs( ents ) do
														
							if v ~= GLOBAL.ThePlayer and v.entity:IsVisible() and v.replica ~= nil and v.replica._ ~= nil and v.replica._.follower ~= nil and 
									tostring( v.replica._.follower:GetLeader() ) == GLOBAL.ThePlayer.GUID.." - "..GLOBAL.ThePlayer.prefab then
																	
								if ClientCurrentFollowers <= 5 then
									if ClientCurrentFollowers == 0 then 
										follow1 = v
									end
									if ClientCurrentFollowers == 1 and v ~= follow1 then 
										follow2 = v 
									end
									if ClientCurrentFollowers == 2 and v ~= follow1 and v ~= follow2 then 
										follow3 = v 										
									end
									if ClientCurrentFollowers == 3 and v ~= follow1 and v ~= follow2 and v ~= follow3 then 
										follow4 = v 
									end
									if ClientCurrentFollowers == 4 and v ~= follow1 and v ~= follow2 and v ~= follow3 and v ~= follow4 then 
										follow5 = v 
									end
									if ClientCurrentFollowers == 5 and v ~= follow1 and v ~= follow2 and v ~= follow3 and v ~= follow4 and v ~= follow5 then 
										follow6 = v 
									end
									leader = GLOBAL.ThePlayer.GUID
									ClientCurrentFollowers = ClientCurrentFollowers + 1
								end
								
							end
							
						end
					
						print( "Follower Count 2:", ClientCurrentFollowers )
					
						if ClientCurrentFollowers < 6 then controls.clientfollower6:Hide() end
						if ClientCurrentFollowers < 5 then controls.clientfollower5:Hide() end
						if ClientCurrentFollowers < 4 then controls.clientfollower4:Hide() end
						if ClientCurrentFollowers < 3 then controls.clientfollower3:Hide() end
						if ClientCurrentFollowers < 2 then controls.clientfollower2:Hide() end
						if ClientCurrentFollowers < 1 then controls.clientfollower1:Hide() end 

						print( "Special Followers 2: ", follow1, follow2 )						
						
						if follow1 ~= nil then
							SendModRPCToServer(MOD_RPC.ShowMeHint.Hint, leader, ClientCurrentFollowers, follow1, follow2, follow3, follow4, follow5, follow6)
						end
					
					end
				
				end
				
			end)
		end)
	end
	
	AddModRPCHandler("ShowMeHint", "Hint", function(player, leader, following, follower1, follower2, follower3, follower4, follower5, follower6)
		if player.player_classified == nil then
			print("ERROR: player_classified not found!")
			return
		end
		if follower1 ~= nil and follower1.components ~= nil then
			local s = GetTestString(player, leader, following, follower1, follower2, follower3, follower4, follower5, follower6)
			if s ~= "" then
				player.player_classified.net_showme_hint:set(s)
			end
		end
	end)

	AddPrefabPostInit("player_classified",function(inst)
		inst.showme_hint = ""
		inst.net_showme_hint = GLOBAL.net_string( inst.GUID, "showme_hint", "showme_hint_dirty" )
		if CLIENT_SIDE then
			inst:ListenForEvent( "showme_hint_dirty", function( inst )
				inst.showme_hint = inst.net_showme_hint:value()
				
				if GLOBAL.TheWorld.ismastersim then
				
				else
				
					local Profile = require("playerprofile")()

					local increment = 60 + ( Profile:GetHUDSize() * 4 )
					local ClientCurrentBadge = nil
					local ClientBadgeV = -60
					
					for k, v in ipairs ( string.split( inst.showme_hint, "¦" ) ) do
						
						print( "Data Returned: ", k, v )
						
						if k % 2 == 0 then ClientBadgeV = -100 else ClientBadgeV = -60 end					
					
						if k == 1 then 
							ClientCurrentBadge = controls.clientfollower1
						elseif k == 2 then 
							ClientCurrentBadge = controls.clientfollower2
						elseif k == 3 then 
							ClientCurrentBadge = controls.clientfollower3
						elseif k == 4 then 
							ClientCurrentBadge = controls.clientfollower4
						elseif k == 5 then 
							ClientCurrentBadge = controls.clientfollower5
						elseif k == 6 then 
							ClientCurrentBadge = controls.clientfollower6 
						end	
						
						for a, b in ipairs ( string.split( v, "|" ) ) do

							if a == 3 then
								ClientCurrentBadge.anim:GetAnimState():SetBank( b )
								ClientCurrentBadge.anim:GetAnimState():SetBuild( b )
							end
							
							if a == 4 then
								ClientCurrentBadge.myname:SetString( b )
							end 
							
							if a == 5 then
								ClientCurrentBadge.loyaltime:SetPercent( GLOBAL.tonumber( b ) )
								ClientCurrentBadge.loyaltime.num:SetString( GLOBAL.tostring( math.ceil( GLOBAL.tonumber( b ) * 100 ) ) .. "%" )                            
							end
							
							if a == 7 then
								ClientCurrentBadge:SetPercent( GLOBAL.tonumber( b ) )	
								if GLOBAL.tonumber( b ) < .15 then 
									ClientCurrentBadge.pulse:GetAnimState():SetMultColour(1,0,0,1) -- Red
									ClientCurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")											
								elseif GLOBAL.tonumber( b ) < .3 then 
									ClientCurrentBadge.pulse:GetAnimState():SetMultColour(1,.5,0,1) -- Orange
									ClientCurrentBadge.pulse:GetAnimState():PlayAnimation("pulse")
								end
							end 

							if a == 8 then
								ClientCurrentBadge.num:SetString( b )
							end
							
						end

						ClientCurrentBadge:Show()
						ClientCurrentBadge.loyaltime:Show()
						ClientCurrentBadge.myname:Show()
						
						ClientCurrentBadge:SetScale(1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10),1 + ((Profile:GetHUDSize() / 2) / 10))
						ClientCurrentBadge:SetPosition(104 + ((k - 1) * increment) + (Profile:GetHUDSize() * 4.8), ClientBadgeV - Profile:GetHUDSize(), 50)
												
					end	

				end
				
			end)
		end
	end)