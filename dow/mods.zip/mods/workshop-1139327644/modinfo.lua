name = "Follower Badges Together (Updated)"
description = "Adds a health badge for your followers\n\nBelow the health badge is the followers loyalty percentage\n\nAbove is the name"

author = "Ram"

api_version = 10
version = "4"

icon_atlas = "modicon.xml"
icon = "modicon.tex"

forumthread = ""

dst_compatible = true
all_clients_require_mod = true
client_only_mod = false

local function range(a, z, step, default, pre, defaultpre)

	local function append(t, i)
		t[#t + 1] = i
		return t
	end

	local opts = {}

	for i = a, z, step do
		if i == default then
			append(opts, {description = defaultpre..i.." (default)", data = i})
		else
			append(opts, {description = pre..i, data = i})
		end
	end

	if #opts > 0 then
		local fdata = opts[#opts].data
		if fdata < z and fdata + step - z < 1e-10 then
			append(opts, {description = z, data = z})
		end
	end

	return opts

end

configuration_options =
{
	
	{
		name = "OptionMaxFollowers",
		label = "Maximum Badges",
		options = range(1, 6, 1, 6, "", ""),		
		default = 6,
	},

	{
		name = "OptionCheckingForFollowers",
		label = "Check for Followers",
		options = range(.1, 2, .1, .5, "", ""),
		default = .5,
	},

	{
		name = "OptionHUDdown",
		label = "Badges Up(-) Down(+)",
		options = range(-300, 300, 10, 0, "", ""),
		default = 0,
	},

	{
		name = "OptionHUDhorizontal",
		label = "Badges Left(-) Right(+)",
		options = range(-900, 900, 10, 0, "", ""),
		default = 0,
	},

}