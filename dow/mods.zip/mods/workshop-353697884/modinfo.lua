name = "Craftable Gears"
description = "A surprisingly complex pile of mechanical stuff."
author = "Bmoney3600"
version = "2.0.7"

forumthread = ""

-- This lets other players know if your mod is out of date, update it to match the current version in the game
api_version = 10

-- Can specify a custom icon for this mod!
icon_atlas = "Craftable Gears.xml"
icon = "Craftable Gears.tex"

-- Specify compatibility with the game!
dont_starve_compatible = true
reign_of_giants_compatible = true
dst_compatible = true
all_clients_require_mod = true