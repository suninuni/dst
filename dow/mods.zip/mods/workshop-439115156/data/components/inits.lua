-- Initialize container component.
use "data/components/container"

-- Initialize inventory component.
--use "data/components/inventory"


AddReplicableComponent( "characterspecific" )